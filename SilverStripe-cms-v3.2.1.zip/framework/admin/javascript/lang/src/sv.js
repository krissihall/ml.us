{
    "CMSMAIN.SELECTONEPAGE": "Var vänlig och välj minst en sida",
    "CMSMAIN.BATCH_UNPUBLISH_PROMPT": "Du har valt {num} sida/sidor\n\nVill du verkligen avpublicera",
    "CMSMAIN.BATCH_PUBLISH_PROMPT": "Du har valt {num} sida/sidor.\nVill du verkligen publicera dem.",
    "CMSMAIN.BATCH_DELETE_PROMPT": "Du har valt {num} sida/sidor\n\nVill du verkligen radera dem.",
    "CMSMAIN.BATCH_ARCHIVE_PROMPT": "You have {num} page(s) selected.\n\nAre you sure you want to archive these pages?\n\nThese pages and all of their children pages will be unpublished and sent to the archive.",
    "CMSMAIN.BATCH_RESTORE_PROMPT": "You have {num} page(s) selected.\n\nDo you really want to restore to stage?\n\nChildren of archived pages will be restored to the root level, unless those pages are also being restored.",
    "CMSMAIN.BATCH_DELETELIVE_PROMPT": "You have {num} page(s) selected.\n\nDo you really want to delete these pages from live?",
    "LeftAndMain.CONFIRMUNSAVED": "Är du säker på att du vill lämna denna sida?\n\nVARNING: Dina ändringar har inte sparats.\n\nTryck OK för att lämna sidan eller Avbryt för att stanna på aktuell sida.",
    "LeftAndMain.CONFIRMUNSAVEDSHORT": "WARNING: Your changes have not been saved.",
    "SecurityAdmin.BATCHACTIONSDELETECONFIRM": "Vill du verkligen radera %s grupper?",
    "ModelAdmin.SAVED": "Sparad",
    "ModelAdmin.REALLYDELETE": "Vill du verkligen radera?",
    "ModelAdmin.DELETED": "Raderad",
    "ModelAdmin.VALIDATIONERROR": "Valideringsfel",
    "LeftAndMain.PAGEWASDELETED": "Sidan raderades. För att redigera en sida, välj den i menyn till vänster."
}