{
    "CMSMAIN.SELECTONEPAGE": "Bitte mindestens eine Seite auswählen",
    "CMSMAIN.BATCH_UNPUBLISH_PROMPT": "Sie haben {num} Seite(n) ausgewählt.\n\nWollen Sie wirklich die Veröffentlichung zurücknehmen?",
    "CMSMAIN.BATCH_PUBLISH_PROMPT": "Sie haben {num} Seite(n) ausgewählt.\n\nWollen Sie diese wirklich veröffentlichen?",
    "CMSMAIN.BATCH_DELETE_PROMPT": "Sie haben {num} Seite(n) ausgewählt.\n\nWollen Sie diese wirklich löschen?",
    "CMSMAIN.BATCH_ARCHIVE_PROMPT": "Sie haben {num} Seite(n) ausgewählt.\n\nWollen Sie diese wirklich archivieren?\n\nDiese Seiten und alle Unterseiten davon werden von der veröffentlichen Seite gelöscht und in das Archiv verschoben.",
    "CMSMAIN.BATCH_RESTORE_PROMPT": "Sie haben {num} Seite(n) ausgewählt.\\n\\nWollen Sie diese wirklich wiederherstellen?\\n\\nUnterseiten von archivierten Seiten werden auf der Root-Ebene wiederhergestellt, es sei denn, diese Seiten werden ebenfalls wiederhergestellt.",
    "CMSMAIN.BATCH_DELETELIVE_PROMPT": "Sie haben {num} Seite(n) ausgewählt.\n\nWollen Sie diese wirklich von der veröfffentlichten Seite löschen?",
    "LeftAndMain.CONFIRMUNSAVED": "Sind Sie sicher, dass Sie die Seite verlassen möchten?\n\nWARNUNG: Ihre Änderungen werden nicht gespeichert.\n\nDrücken Sie \"OK\" um fortzufahren, oder \"Abbrechen\" um auf dieser Seite zu bleiben.",
    "LeftAndMain.CONFIRMUNSAVEDSHORT": "WARNUNG: Ihre Änderungen wurden nicht gespeichert.",
    "SecurityAdmin.BATCHACTIONSDELETECONFIRM": "Möchten Sie wirklich %s Gruppen löschen?",
    "ModelAdmin.SAVED": "Gespeichert",
    "ModelAdmin.REALLYDELETE": "Wirklich löschen?",
    "ModelAdmin.DELETED": "Gelöscht",
    "ModelAdmin.VALIDATIONERROR": "Validationsfehler",
    "LeftAndMain.PAGEWASDELETED": "Diese Seite wurde gelöscht."
}