{
    "CMSMAIN.SELECTONEPAGE": "Por favor, seleccione al menos una página",
    "CMSMAIN.BATCH_UNPUBLISH_PROMPT": "Ud tiene {num} página(s) seleccionada(s).\n\n¿Realmente la(s) quiere retirar de publicación?",
    "CMSMAIN.BATCH_PUBLISH_PROMPT": "Ud tiene {num} página(s) seleccionada(s).\n\n¿Realmente la(s) quiere publicar?",
    "CMSMAIN.BATCH_DELETE_PROMPT": "Ud tiene {num} página(s) seleccionada(s).\n\n¿Realmente quiere eliminarla(s)?",
    "CMSMAIN.BATCH_ARCHIVE_PROMPT": "Ud tiene {num} páginas seleccionadas.\n\n¿Está seguro de querer archivar estas páginas?\n\nEstas páginas y sus hijas se retirarán de publicación y se enviarán al archivo.",
    "CMSMAIN.BATCH_RESTORE_PROMPT": "You have {num} page(s) selected.\n\nDo you really want to restore to stage?\n\nChildren of archived pages will be restored to the root level, unless those pages are also being restored.",
    "CMSMAIN.BATCH_DELETELIVE_PROMPT": "You have {num} page(s) selected.\n\nDo you really want to delete these pages from live?",
    "LeftAndMain.CONFIRMUNSAVED": "¿Estás seguro que quieres navegar fuera de esta página?⏎\n⏎\nADVERTENCIA: Tus cambios no han sido guardados.⏎\n⏎\nPresionar OK para continuar o Cancelar para continuar en la página actual",
    "LeftAndMain.CONFIRMUNSAVEDSHORT": "ADVERTENCIA: Tus cambios no han sido guardados.",
    "SecurityAdmin.BATCHACTIONSDELETECONFIRM": "¿Realmente quieres eliminar el grupo %s?",
    "ModelAdmin.SAVED": "Guardado",
    "ModelAdmin.REALLYDELETE": "Estás seguro que quieres eliminarla?",
    "ModelAdmin.DELETED": "Eliminado",
    "ModelAdmin.VALIDATIONERROR": "Error de validación",
    "LeftAndMain.PAGEWASDELETED": "Esta página fue eliminada. Para editar una página, seleccionarla desde la izquierda"
}