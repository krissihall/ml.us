{
    "CMSMAIN.SELECTONEPAGE": "Prosím, vyberte nejméně 1 stránku",
    "CMSMAIN.BATCH_UNPUBLISH_PROMPT": "Máte vybráno {num} stránek.\n\nSkutečně je chcete nezveřejnit?",
    "CMSMAIN.BATCH_PUBLISH_PROMPT": "Máte vybráno {num} stránek.\n\nSkutečně je chcete zveřejnit?",
    "CMSMAIN.BATCH_DELETE_PROMPT": "Máte vybráno {num} stránek.\n\nSkutečně je chcete vymazat?",
    "CMSMAIN.BATCH_ARCHIVE_PROMPT": "Vybráno {num} stránek.\n\nSkutečně chcete archivovat tyto stránky?\n\nTyto stránky a její všechny podstránky budou nezveřejněny a odeslány do archívu.",
    "CMSMAIN.BATCH_RESTORE_PROMPT": "Vybráno {num} stránek.\n\nSkutečně chcete obnovit?\n\nPodstránky archivovaných stránek budou obnoveny do nejvzšší úrovně, pokud tyto stránky budou také obnoveny.",
    "CMSMAIN.BATCH_DELETELIVE_PROMPT": "Máte vybráno {num} stránek.\n\nSkutečně chcete vymazat tyto stránky z webu?",
    "LeftAndMain.CONFIRMUNSAVED": "Určitě chcete opustit navigaci z této stránky?\n\nUPOZORNĚNÍ: Vaše změny nebyly uloženy.\n\nStlačte OK pro pokračovat, nebo Cancel, zůstanete na této stránce.",
    "LeftAndMain.CONFIRMUNSAVEDSHORT": "UPOZORNĚNÍ: Vaše změny nebyly uloženy.",
    "SecurityAdmin.BATCHACTIONSDELETECONFIRM": "Skutečně chcete smazat %s skupiny?",
    "ModelAdmin.SAVED": "Uloženo",
    "ModelAdmin.REALLYDELETE": "Skutečně chcete smazat?",
    "ModelAdmin.DELETED": "Smazáno",
    "ModelAdmin.VALIDATIONERROR": "Chyba platnosti",
    "LeftAndMain.PAGEWASDELETED": "Tato stránka byla smazána. Pro editaci stránky, vyberte ji vlevo."
}