{
    "CMSMAIN.SELECTONEPAGE": "Prosím, vyberte najmenej 1 stránku",
    "CMSMAIN.BATCH_UNPUBLISH_PROMPT": "Máte vybratých {num} stránok.\n\nSkutočne ich chcete nezverejniť?",
    "CMSMAIN.BATCH_PUBLISH_PROMPT": "Máte vybratých {num} stránok.\n\nSkutočne ich chcete zverejniť?",
    "CMSMAIN.BATCH_DELETE_PROMPT": "Máte vybratých {num} stránok.\n\nSkutočne ich chcete vymazať?",
    "CMSMAIN.BATCH_ARCHIVE_PROMPT": "Vybrali ste {num} stránok.\n\nUrčite chcete archivovať tieto stránky?\n\nTieto stránky a jej všetky podstránky budú nezverejnené a odoslané do archívu.",
    "CMSMAIN.BATCH_RESTORE_PROMPT": "Vybrali ste {num} stránok.\n\nSkutočne chcete obnoviť?\n\nPodstránky archivovaných stránok budú obnovené do najvyššej úrovne, pokiaľ tieto stránky budú tiež obnovené.",
    "CMSMAIN.BATCH_DELETELIVE_PROMPT": "Máte vybratých {num} stránok.\n\nSkutočne chcete tieto stránky vymazať z webu?",
    "LeftAndMain.CONFIRMUNSAVED": "Určite chcete opustiť navigáciu z tejto stránky?\n\nUPOZORNENIE: Vaše zmeny neboli uložené.\n\nStlačte OK pre pokračovať, alebo Cancel, ostanete na teto stránke.",
    "LeftAndMain.CONFIRMUNSAVEDSHORT": "UPOZORNENIE: Vaše zmeny neboli uložené.",
    "SecurityAdmin.BATCHACTIONSDELETECONFIRM": "Skutočne chcete zmazať % skupiny?",
    "ModelAdmin.SAVED": "Uložené",
    "ModelAdmin.REALLYDELETE": "Skutočně chcete zmazať?",
    "ModelAdmin.DELETED": "Zmazané",
    "ModelAdmin.VALIDATIONERROR": "Chyba platnosti",
    "LeftAndMain.PAGEWASDELETED": "Táto stránka bola zmazaná. Pre editáciu stránky, vyberte ju vľavo."
}