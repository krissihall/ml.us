<?php

/**
 * @deprecated 3.3.0
 *
 * @package cms
 */
class CMSSettingsController extends SiteConfigLeftAndMain {

	/**
	 * @config
	 * @var int
	 */
	private static $url_priority = 60;

}
